<html>
<head>
<title> NSBM  </title>
<?php
$h=$_REQUEST["fn"];
   echo ("First Name is : $h<br>"); 
$t=$_REQUEST["la"];
   echo ("Last Name is : $t<br>"); 
$a=$_REQUEST["un"];
   echo ("User Name is : $a<br>"); 
$b=$_REQUEST["password"];
   echo ("password is : $b<br>"); 
$c=$_REQUEST["na"];
   echo ("Gender is : $c<br>"); 

$q=$_REQUEST["email"];
   echo ("Email is : $q<br>"); 
$w=$_REQUEST["la"];
   echo ("phone Number is : $w<br>"); 
    
?>
</head>
    <body>
    </body>
    </html>