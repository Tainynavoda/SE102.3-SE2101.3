package employee01obj;
public class Employee01obj {
public static void main(String[] args) 
{
        employee t1=new employee();
    t1.setempage(100);
    t1.setempname("Mr.bogban");
    t1.setDes("Employee");
    t1.display();
        employee t2=new employee();
    t2.setempage(200);
    t2.setempname("Mr.Bird");
    t2.setDes("Employee");
    t2.display();

  
}
    
}
