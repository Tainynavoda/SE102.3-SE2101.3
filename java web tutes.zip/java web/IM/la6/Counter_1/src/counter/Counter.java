package counter;
public class Counter {
    public static void main(String[] args) 
    {
     Counter01 c=new Counter01();
     c.show();
    }
    
}
