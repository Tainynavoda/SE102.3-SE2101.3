package com.mycompany.lab06q2;
public interface Shape 
{
    double calculateArea();
    double calculatePerimeter();
}
