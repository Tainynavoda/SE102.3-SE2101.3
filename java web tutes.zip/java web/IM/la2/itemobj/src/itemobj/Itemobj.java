package itemobj;
public class Itemobj {
    public static void main(String[] args) 
    {
 Monster m1=new Monster(115, "other",40,"mm");
    m1.setlocation(10);
    m1.setdescription("mgr");
    m1.display();
    m1.displaymonster();
    }
    
}
