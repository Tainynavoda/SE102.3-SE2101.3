package pkginterface;
public class Interface {
  public static void main(String[] args) 
  {
      
      
    }
    
}
