package practical5q4;
import java.util.Scanner;
public class Practical5q4 {
public static void main(String[] args) 
{ 
 circle c1= new circle(4, 6);
c1.CalculateArea(); 

Rectangle r1= new Rectangle(4,8);
 r1.CalculateArea();
    }
    
}
