package practical5q4;
public class Rectangle extends Practical5q4
{
     private double height,width;
 public Rectangle(double a,double b)
 {
       height=a;
     width=b;
 }
 
 public double CalculateArea()
 {
     return (height*width);
     
 }
}
