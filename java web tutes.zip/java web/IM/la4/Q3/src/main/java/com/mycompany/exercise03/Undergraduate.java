package com.mycompany.exercise03;
public class Undergraduate extends Student 
{
    //'Undergraduate' class trying to extend the 'Student' class. But it not allowed.
    //Because 'Student' is marked as 'final'.
    //As a result, a compilation error will occur.
}
